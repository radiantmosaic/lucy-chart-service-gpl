#!/usr/bin/env python3
"""Debug Kerykeion methods to find house drawing functions"""
from kerykeion import KerykeionChartSVG
import inspect

# List all methods containing 'house'
house_methods = [m for m in dir(KerykeionChartSVG) if 'house' in m.lower()]
print('Methods containing "house":')
for method in house_methods:
    print(f'  {method}')

print()

# Look for draw/render methods that might be related to houses
draw_methods = [m for m in dir(KerykeionChartSVG) if 'draw' in m.lower() or 'render' in m.lower()]
print('Methods containing "draw" or "render":')
for method in draw_methods:
    print(f'  {method}')

print()

# Check for methods containing 'line', 'cusp', or 'division'
other_methods = [m for m in dir(KerykeionChartSVG) if any(word in m.lower() for word in ['line', 'cusp', 'division', 'segment'])]
print('Methods containing "line", "cusp", "division", or "segment":')
for method in other_methods:
    print(f'  {method}')

print()

# Get all methods and look for SVG generation related ones
all_methods = [m for m in dir(KerykeionChartSVG) if not m.startswith('__') and callable(getattr(KerykeionChartSVG, m))]
svg_methods = [m for m in all_methods if 'svg' in m.lower() or 'make' in m.lower()]
print('Methods containing "svg" or "make":')
for method in svg_methods:
    print(f'  {method}')

print()

# Try to inspect makeWheelOnlySVG to see what it calls
print('Inspecting makeWheelOnlySVG method:')
try:
    source = inspect.getsource(KerykeionChartSVG.makeWheelOnlySVG)
    print("Source code available - looking for house-related calls:")
    for i, line in enumerate(source.split('\n'), 1):
        if any(word in line.lower() for word in ['house', 'cusp', 'draw', 'line']):
            print(f'  Line {i}: {line.strip()}')
except:
    print("  Could not get source code")