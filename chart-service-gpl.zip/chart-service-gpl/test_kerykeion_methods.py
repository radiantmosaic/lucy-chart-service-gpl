#!/usr/bin/env python3
"""Test to find Kerykeion's house-drawing methods"""
import sys
sys.path.insert(0, '/volume2/docker/lucy-bot/chart-service-gpl')

from kerykeion import KerykeionChartSVG, AstrologicalSubject
import inspect

# Create a test subject and chart
subject = AstrologicalSubject('Test', 2024, 1, 1, 12, 0, city='London', nation='GB')
chart = KerykeionChartSVG(subject)

# List all methods that might be related to houses
print("Methods in KerykeionChartSVG that might draw houses:")
for method_name in dir(chart):
    if 'house' in method_name.lower() or 'cusp' in method_name.lower() or 'draw' in method_name.lower():
        if not method_name.startswith('__'):
            print(f"  - {method_name}")

# Check the makeWheelOnlySVG method source if possible
print("\nChecking makeWheelOnlySVG method:")
try:
    source = inspect.getsource(chart.makeWheelOnlySVG)
    # Look for house-related calls
    for line in source.split('\n'):
        if 'house' in line.lower() or 'cusp' in line.lower():
            print(f"  Found: {line.strip()}")
except:
    print("  Could not get source")

# Check what attributes the chart object has
print("\nHouse-related attributes in chart object:")
for attr in dir(chart):
    if 'house' in attr.lower() or 'cusp' in attr.lower():
        if not attr.startswith('__') and not callable(getattr(chart, attr)):
            try:
                value = getattr(chart, attr)
                print(f"  - {attr}: {type(value).__name__}")
            except:
                pass